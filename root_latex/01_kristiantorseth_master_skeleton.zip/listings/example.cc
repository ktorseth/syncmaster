#include <iostream>
using namespace std;

// No comment...
int main() 
{
  cout << "Hello, World!" << endl;
  return 0;
}
